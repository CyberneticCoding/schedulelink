<template>
	<SettingsLayout>
		<template #main>
			<div class="mx-auto ml-10" >

			</div>
		</template>
	</SettingsLayout>
</template>

<script>

import SettingsLayout from "../../Layouts/SettingsLayout.vue";

export default {
	name: "NotificationsPage",
	components: {
		SettingsLayout
	},
}
</script>