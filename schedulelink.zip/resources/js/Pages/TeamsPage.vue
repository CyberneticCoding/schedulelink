<template>
	<MainLayout>
		<template #main>

		</template>
	</MainLayout>
</template>

<script>

import MainLayout from "../Layouts/MainLayout.vue";

export default {
	name: "TeamsPage",
	components: { MainLayout },
}
</script>